import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertRideSchema, insertRideReservationSchema, insertTripHistorySchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix
  const API_PREFIX = "/api";

  // Handle validation errors
  function handleValidationError(error: unknown, res: Response) {
    if (error instanceof ZodError) {
      const validationError = fromZodError(error);
      return res.status(400).json({ message: validationError.message });
    }
    return res.status(500).json({ message: "Unknown server error" });
  }

  // User routes
  app.post(`${API_PREFIX}/users`, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  app.get(`${API_PREFIX}/users/:id`, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json(user);
  });

  app.patch(`${API_PREFIX}/users/:id/preferences`, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    try {
      const preferencesSchema = z.object({
        travelMode: z.enum(['fastest', 'cheapest', 'eco', 'social']).optional(),
        timeFlexibility: z.number().min(0).max(60).optional(),
        vehicleType: z.enum(['gas', 'hybrid', 'electric', 'none']).optional(),
        maxParkingPrice: z.number().optional(),
        parkingReservable: z.boolean().optional(),
        routePreference: z.enum(['eco', 'fastest', 'fuelEfficient', 'multiModal']).optional(),
        notificationEnabled: z.boolean().optional()
      });
      
      const preferences = preferencesSchema.parse(req.body);
      const updatedUser = await storage.updateUserPreferences(id, preferences);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  // Ride routes
  app.get(`${API_PREFIX}/rides`, async (req, res) => {
    const destination = req.query.destination as string;
    
    if (destination) {
      const rides = await storage.getRidesByDestination(destination);
      return res.json(rides);
    }
    
    const rides = await storage.getRides();
    res.json(rides);
  });

  app.get(`${API_PREFIX}/rides/:id`, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ride ID" });
    }
    
    const ride = await storage.getRide(id);
    if (!ride) {
      return res.status(404).json({ message: "Ride not found" });
    }
    
    res.json(ride);
  });

  app.post(`${API_PREFIX}/rides`, async (req, res) => {
    try {
      const rideData = insertRideSchema.parse(req.body);
      const ride = await storage.createRide(rideData);
      res.status(201).json(ride);
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  // Ride reservation routes
  app.post(`${API_PREFIX}/ride-reservations`, async (req, res) => {
    try {
      const reservationData = insertRideReservationSchema.parse(req.body);
      
      // Check if ride exists and has available seats
      const ride = await storage.getRide(reservationData.rideId);
      if (!ride) {
        return res.status(404).json({ message: "Ride not found" });
      }
      
      if (ride.availableSeats <= 0) {
        return res.status(400).json({ message: "No available seats on this ride" });
      }
      
      const reservation = await storage.createRideReservation(reservationData);
      res.status(201).json(reservation);
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  app.get(`${API_PREFIX}/ride-reservations/user/:userId`, async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const reservations = await storage.getRideReservationsByUser(userId);
    res.json(reservations);
  });

  // Parking routes
  app.get(`${API_PREFIX}/parking-spots`, async (req, res) => {
    const lat = req.query.lat as string;
    const lng = req.query.lng as string;
    const radius = parseInt(req.query.radius as string) || 5;
    
    if (lat && lng) {
      const spots = await storage.getParkingSpotsByLocation(lat, lng, radius);
      return res.json(spots);
    }
    
    const spots = await storage.getParkingSpots();
    res.json(spots);
  });

  app.get(`${API_PREFIX}/parking-spots/:id`, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid parking spot ID" });
    }
    
    const spot = await storage.getParkingSpot(id);
    if (!spot) {
      return res.status(404).json({ message: "Parking spot not found" });
    }
    
    res.json(spot);
  });

  // Trip history routes
  app.get(`${API_PREFIX}/trip-history/user/:userId`, async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const trips = await storage.getTripHistoryByUser(userId);
    res.json(trips);
  });

  app.post(`${API_PREFIX}/trip-history`, async (req, res) => {
    try {
      const tripData = insertTripHistorySchema.parse(req.body);
      const trip = await storage.createTripHistory(tripData);
      res.status(201).json(trip);
    } catch (error) {
      handleValidationError(error, res);
    }
  });

  // Route suggestions (mock AI recommendations)
  app.get(`${API_PREFIX}/route-suggestions`, async (req, res) => {
    const origin = req.query.origin as string;
    const destination = req.query.destination as string;
    const preference = req.query.preference as string || 'eco';
    
    if (!origin || !destination) {
      return res.status(400).json({ message: "Origin and destination are required" });
    }
    
    // Mock AI-generated route suggestions
    const suggestions = [
      {
        id: 1,
        name: "Hybrid Route",
        duration: 25,
        distance: 4.5,
        arrivalTime: "8:32 AM",
        co2Reduction: 45,
        segments: [
          { type: "walk", duration: 5 },
          { type: "bus", duration: 15 },
          { type: "walk", duration: 5 }
        ]
      },
      {
        id: 2,
        name: "EV-Optimized Route",
        duration: 32,
        distance: 5.2,
        arrivalTime: "8:39 AM",
        co2Reduction: 100,
        segments: [
          { type: "ev", duration: 32, hasChargingStation: true }
        ]
      }
    ];
    
    res.json(suggestions);
  });

  const httpServer = createServer(app);
  return httpServer;
}
