import {
  users, User, InsertUser,
  rides, Ride, InsertRide,
  rideReservations, RideReservation, InsertRideReservation,
  parkingSpots, ParkingSpot, InsertParkingSpot,
  tripHistory, TripHistory, InsertTripHistory,
  UserPreferences
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPreferences(userId: number, preferences: UserPreferences): Promise<User | undefined>;
  
  // Ride methods
  getRides(): Promise<Ride[]>;
  getRidesByDestination(destination: string): Promise<Ride[]>;
  getRide(id: number): Promise<Ride | undefined>;
  createRide(ride: InsertRide): Promise<Ride>;
  updateRideAvailableSeats(rideId: number, seats: number): Promise<Ride | undefined>;
  
  // Ride reservation methods
  createRideReservation(reservation: InsertRideReservation): Promise<RideReservation>;
  getRideReservationsByUser(userId: number): Promise<RideReservation[]>;
  
  // Parking methods
  getParkingSpots(): Promise<ParkingSpot[]>;
  getParkingSpotsByLocation(lat: string, lng: string, radius: number): Promise<ParkingSpot[]>;
  getParkingSpot(id: number): Promise<ParkingSpot | undefined>;
  updateParkingSpotAvailability(id: number, availableSpots: number): Promise<ParkingSpot | undefined>;
  createParkingSpot(spot: InsertParkingSpot): Promise<ParkingSpot>;
  
  // Trip history methods
  getTripHistoryByUser(userId: number): Promise<TripHistory[]>;
  createTripHistory(trip: InsertTripHistory): Promise<TripHistory>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private rides: Map<number, Ride>;
  private rideReservations: Map<number, RideReservation>;
  private parkingSpots: Map<number, ParkingSpot>;
  private tripHistory: Map<number, TripHistory>;
  
  private userId: number;
  private rideId: number;
  private reservationId: number;
  private parkingId: number;
  private tripId: number;

  constructor() {
    this.users = new Map();
    this.rides = new Map();
    this.rideReservations = new Map();
    this.parkingSpots = new Map();
    this.tripHistory = new Map();
    
    this.userId = 1;
    this.rideId = 1;
    this.reservationId = 1;
    this.parkingId = 1;
    this.tripId = 1;
    
    // Initialize with sample data
    this.initSampleData();
  }

  private initSampleData() {
    // Sample users
    const user1: User = {
      id: this.userId++,
      username: "pranav",
      password: "password123",
      fullName: "Pranav",
      email: "pranav@navisense.com",
      preferences: {
        travelMode: "fastest",
        timeFlexibility: 15,
        vehicleType: "hybrid",
        maxParkingPrice: 10,
        parkingReservable: true,
        routePreference: "eco",
        notificationEnabled: true
      },
      createdAt: new Date()
    };
    this.users.set(user1.id, user1);

    // Sample rides
    const ride1: Ride = {
      id: this.rideId++,
      driverId: user1.id,
      origin: "123 Main Street, City Center",
      destination: "456 Business District",
      departureTime: new Date(Date.now() + 60 * 60 * 1000), // 1 hour from now
      arrivalTime: new Date(Date.now() + 90 * 60 * 1000), // 1.5 hours from now
      availableSeats: 3,
      cost: 550, // $5.50
      description: "Carpool with Alex",
      status: "active",
      createdAt: new Date()
    };
    this.rides.set(ride1.id, ride1);

    // Sample parking spots
    const parking1: ParkingSpot = {
      id: this.parkingId++,
      name: "Central Garage",
      address: "789 Downtown Street",
      lat: "40.7128",
      lng: "-74.0060",
      hourlyRate: 450, // $4.50/hr
      totalSpots: 50,
      availableSpots: 8,
      restrictions: "24/7 access",
      features: ["secure", "covered"],
      createdAt: new Date()
    };
    
    const parking2: ParkingSpot = {
      id: this.parkingId++,
      name: "Street Parking - Main St",
      address: "123 Main Street",
      lat: "40.7130",
      lng: "-74.0065",
      hourlyRate: 200, // $2.00/hr
      totalSpots: 10,
      availableSpots: 3,
      restrictions: "2hr limit, until 6PM",
      features: ["metered"],
      createdAt: new Date()
    };
    
    this.parkingSpots.set(parking1.id, parking1);
    this.parkingSpots.set(parking2.id, parking2);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async updateUserPreferences(userId: number, preferences: UserPreferences): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = {
      ...user,
      preferences: {
        ...user.preferences,
        ...preferences
      }
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Ride methods
  async getRides(): Promise<Ride[]> {
    return Array.from(this.rides.values());
  }

  async getRidesByDestination(destination: string): Promise<Ride[]> {
    return Array.from(this.rides.values()).filter(
      ride => ride.destination.toLowerCase().includes(destination.toLowerCase())
    );
  }

  async getRide(id: number): Promise<Ride | undefined> {
    return this.rides.get(id);
  }

  async createRide(insertRide: InsertRide): Promise<Ride> {
    const id = this.rideId++;
    const ride: Ride = { ...insertRide, id, createdAt: new Date() };
    this.rides.set(id, ride);
    return ride;
  }

  async updateRideAvailableSeats(rideId: number, seats: number): Promise<Ride | undefined> {
    const ride = await this.getRide(rideId);
    if (!ride) return undefined;
    
    const updatedRide = {
      ...ride,
      availableSeats: seats
    };
    
    this.rides.set(rideId, updatedRide);
    return updatedRide;
  }

  // Ride reservation methods
  async createRideReservation(insertReservation: InsertRideReservation): Promise<RideReservation> {
    const id = this.reservationId++;
    const reservation: RideReservation = { ...insertReservation, id, createdAt: new Date() };
    this.rideReservations.set(id, reservation);
    
    // Update available seats on the ride
    const ride = await this.getRide(reservation.rideId);
    if (ride && ride.availableSeats > 0) {
      await this.updateRideAvailableSeats(ride.id, ride.availableSeats - 1);
    }
    
    return reservation;
  }

  async getRideReservationsByUser(userId: number): Promise<RideReservation[]> {
    return Array.from(this.rideReservations.values()).filter(
      reservation => reservation.userId === userId
    );
  }

  // Parking methods
  async getParkingSpots(): Promise<ParkingSpot[]> {
    return Array.from(this.parkingSpots.values());
  }

  async getParkingSpotsByLocation(lat: string, lng: string, radius: number): Promise<ParkingSpot[]> {
    // In a real app, this would calculate distance
    // For now, just return all spots
    return this.getParkingSpots();
  }

  async getParkingSpot(id: number): Promise<ParkingSpot | undefined> {
    return this.parkingSpots.get(id);
  }

  async updateParkingSpotAvailability(id: number, availableSpots: number): Promise<ParkingSpot | undefined> {
    const spot = await this.getParkingSpot(id);
    if (!spot) return undefined;
    
    const updatedSpot = {
      ...spot,
      availableSpots
    };
    
    this.parkingSpots.set(id, updatedSpot);
    return updatedSpot;
  }

  async createParkingSpot(insertSpot: InsertParkingSpot): Promise<ParkingSpot> {
    const id = this.parkingId++;
    const spot: ParkingSpot = { ...insertSpot, id, createdAt: new Date() };
    this.parkingSpots.set(id, spot);
    return spot;
  }

  // Trip history methods
  async getTripHistoryByUser(userId: number): Promise<TripHistory[]> {
    return Array.from(this.tripHistory.values()).filter(
      trip => trip.userId === userId
    );
  }

  async createTripHistory(insertTrip: InsertTripHistory): Promise<TripHistory> {
    const id = this.tripId++;
    const trip: TripHistory = { ...insertTrip, id, createdAt: new Date() };
    this.tripHistory.set(id, trip);
    return trip;
  }
}

export const storage = new MemStorage();
