import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Home, Map, Car, History, User, Building, Home as HomeIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

interface RecentDestination {
  id: number;
  name: string;
  address: string;
  icon: React.ReactNode;
}

const DesktopSidebar = () => {
  const [location] = useLocation();
  
  const navItems: NavItem[] = [
    { path: '/', label: 'Home', icon: <Home className="h-5 w-5" /> },
    { path: '/explore', label: 'Explore', icon: <Map className="h-5 w-5" /> },
    { path: '/rides', label: 'My Rides', icon: <Car className="h-5 w-5" /> },
    { path: '/parking', label: 'Parking', icon: (
      <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h8a2 2 0 012 2v10a2 2 0 01-2 2H8a2 2 0 01-2-2V9a2 2 0 012-2zm6 8a2 2 0 100-4 2 2 0 000 4z" />
      </svg>
    ) },
    { path: '/history', label: 'History', icon: <History className="h-5 w-5" /> },
    { path: '/profile', label: 'Profile', icon: <User className="h-5 w-5" /> },
  ];

  const recentDestinations: RecentDestination[] = [
    {
      id: 1,
      name: 'Office Building',
      address: '123 Business St',
      icon: <Building className="text-neutral-600" />
    },
    {
      id: 2,
      name: 'Home',
      address: '456 Residential Ave',
      icon: <HomeIcon className="text-neutral-600" />
    }
  ];

  const [isExpanded, setIsExpanded] = useState(false);
  
  return (
    <div 
      className={`hidden md:block fixed top-0 left-0 bottom-0 bg-white border-r border-neutral-200 z-30 pt-16 transition-all duration-300 ease-in-out ${
        isExpanded ? 'w-56' : 'w-20'
      }`}
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      <div className="p-2 overflow-hidden">
        
        
        <div className="space-y-1">
          {navItems.map((item) => (
            <div
              key={item.path}
              onClick={() => window.location.href = item.path}
              className={`w-full flex items-center text-left px-3 py-2 rounded-lg cursor-pointer transition-colors duration-200 ${
                location === item.path 
                  ? 'bg-primary-50 text-primary-700' 
                  : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <span className={`inline-flex items-center justify-center sidebar-nav-icon ${!isExpanded && 'mx-auto'}`}>{item.icon}</span>
              {isExpanded && (
                <span className="ml-3 transition-opacity duration-300 ease-in-out">{item.label}</span>
              )}
            </div>
          ))}
        </div>
        
        {isExpanded && (
          <div className="mt-8 pt-4 border-t border-neutral-200 transition-opacity duration-300 ease-in-out sidebar-expanded">
            <div className="text-sm text-neutral-500 mb-2">Recent Destinations</div>
            <div className="space-y-2">
              {recentDestinations.map((destination) => (
                <div key={destination.id} className="flex items-center px-3 py-2 hover:bg-neutral-100 rounded-lg cursor-pointer">
                  <div className="bg-neutral-200 rounded p-1 mr-3 flex-shrink-0">
                    {destination.icon}
                  </div>
                  <div className="min-w-0 overflow-hidden">
                    <p className="text-sm truncate">{destination.name}</p>
                    <p className="text-xs text-neutral-500 truncate">{destination.address}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DesktopSidebar;
