import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Star, User, Clock } from 'lucide-react';

interface RideOption {
  id: number;
  type: 'carpool' | 'bus';
  title: string;
  price: number;
  departureTime: string;
  arrivalTime: string;
  rating?: number;
  seatsLeft: number | string;
  walkTime?: number;
}

const RidesTab = () => {
  const [travelPreference, setTravelPreference] = useState('fastest');
  const [timeFlexibility, setTimeFlexibility] = useState([15]);
  const [isLoading, setIsLoading] = useState(false); // Added state for loading

  const { data: rideOptions, isLoading: apiIsLoading } = useQuery({
    queryKey: ['/api/rides'],
    enabled: true, // Automatically fetch rides on component mount
  });

  // Fallback ride options if API isn't available yet
  const fallbackRideOptions: RideOption[] = [
    {
      id: 1,
      type: 'carpool',
      title: 'Carpool with Alex',
      price: 550, // In cents, $5.50
      departureTime: '7:45 AM',
      arrivalTime: '8:25 AM',
      rating: 4.8,
      seatsLeft: 2
    },
    {
      id: 2,
      type: 'bus',
      title: 'Express Bus 42',
      price: 275, // $2.75
      departureTime: '7:35 AM',
      arrivalTime: '8:32 AM',
      walkTime: 5,
      seatsLeft: 'Many'
    }
  ];

  // Use actual data or fallback
  const displayRideOptions = rideOptions || fallbackRideOptions;

  const handlePreferenceClick = (preference: string) => {
    setTravelPreference(preference);
  };

  const formatPrice = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}`;
  };

  const handleReserveSeat = async (rideId: number) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
    setIsLoading(false);
    // Add bounce animation to success message
    const element = document.getElementById(`ride-${rideId}`);
    if (element) {
      element.classList.add('bounce-once');
    }
    console.log(`Reserving seat for ride ${rideId}`);
  };

  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold mb-3">AI-Powered Ride Matching</h3>

      {/* Travel Preferences Card */}
      <div className="bg-neutral-50 rounded-lg p-4 mb-4">
        <h4 className="text-sm font-medium text-neutral-500 mb-2">Your Travel Preferences</h4>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <Button 
            variant={travelPreference === 'fastest' ? 'secondary' : 'outline'}
            className={`py-2 px-3 ${travelPreference === 'fastest' ? 'bg-primary-50 border-primary-200 text-primary-700' : ''}`}
            onClick={() => handlePreferenceClick('fastest')}
          >
            <Clock className="mr-2 h-4 w-4" /> Fastest
          </Button>
          <Button 
            variant={travelPreference === 'cheapest' ? 'secondary' : 'outline'}
            className={`py-2 px-3 ${travelPreference === 'cheapest' ? 'bg-primary-50 border-primary-200 text-primary-700' : ''}`}
            onClick={() => handlePreferenceClick('cheapest')}
          >
            <span className="mr-2">$</span> Cheapest
          </Button>
          <Button 
            variant={travelPreference === 'social' ? 'secondary' : 'outline'}
            className={`py-2 px-3 ${travelPreference === 'social' ? 'bg-primary-50 border-primary-200 text-primary-700' : ''}`}
            onClick={() => handlePreferenceClick('social')}
          >
            <User className="mr-2 h-4 w-4" /> Social
          </Button>
          <Button 
            variant={travelPreference === 'eco' ? 'secondary' : 'outline'}
            className={`py-2 px-3 ${travelPreference === 'eco' ? 'bg-primary-50 border-primary-200 text-primary-700' : ''}`}
            onClick={() => handlePreferenceClick('eco')}
          >
            <svg className="mr-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg> Eco-Friendly
          </Button>
        </div>

        {/* Time selection */}
        <div className="flex items-center mb-1">
          <p className="text-sm text-neutral-600 mr-auto">When do you need to arrive?</p>
          <div className="flex items-center">
            <span className="text-sm font-medium">8:30 AM</span>
            <svg className="ml-1 h-4 w-4 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>

        {/* Flexibility slider */}
        <div className="mb-3">
          <p className="text-xs text-neutral-500 mb-1">Time Flexibility</p>
          <Slider
            defaultValue={[15]}
            max={60}
            step={5}
            value={timeFlexibility}
            onValueChange={setTimeFlexibility}
          />
          <div className="flex justify-between text-xs text-neutral-400 mt-1">
            <span>Exact</span>
            <span>±{timeFlexibility[0]} min</span>
            <span>±1 hour</span>
          </div>
        </div>
      </div>

      {/* Recommended Rides */}
      <h4 className="text-base font-medium mb-3">Recommended for You</h4>

      {apiIsLoading ? (
        <div className="space-y-3">
          <div className="bg-neutral-100 h-28 rounded-lg animate-pulse"></div>
          <div className="bg-neutral-100 h-28 rounded-lg animate-pulse"></div>
        </div>
      ) : (
        <>
          {displayRideOptions.map((ride) => (
            <div key={ride.id} id={`ride-${ride.id}`} className="bg-white border border-neutral-200 rounded-lg p-4 mb-3 hover:shadow-md transition-shadow bounce-once"> {/* Added id and class for animation */}
              <div className="flex items-start">
                <div className={`rounded-full p-2 mr-3 ${ride.type === 'carpool' ? 'bg-primary-100' : 'bg-blue-100'}`}>
                  {ride.type === 'carpool' ? (
                    <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
                    </svg>
                  ) : (
                    <svg className="h-5 w-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                    </svg>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <h5 className="font-medium">{ride.title}</h5>
                    <span className="text-sm font-medium text-primary">{formatPrice(ride.price)}</span>
                  </div>
                  <p className="text-sm text-neutral-600 mb-1">
                    Leaves at {ride.departureTime} • Arrives {ride.arrivalTime}
                  </p>
                  <div className="flex items-center text-xs text-neutral-500 mb-2">
                    {ride.rating && (
                      <span className="flex items-center mr-3">
                        <Star className="h-3 w-3 fill-amber-500 text-amber-500 mr-1" /> {ride.rating}
                      </span>
                    )}
                    {ride.walkTime && (
                      <span className="flex items-center mr-3">
                        <svg className="h-3 w-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
                        </svg>
                        {ride.walkTime} min walk
                      </span>
                    )}
                    <span className="flex items-center">
                      <User className="h-3 w-3 mr-1" /> {ride.seatsLeft} seats left
                    </span>
                  </div>
                  <Button 
                    className="w-full mt-2" 
                    variant="default"
                    onClick={() => handleReserveSeat(ride.id)}
                  >
                    {ride.type === 'carpool' ? 'Reserve Seat' : 'Get Ticket'}
                  </Button>
                </div>
              </div>
            </div>
          ))}

          <Button variant="ghost" className="w-full py-3 text-primary font-medium">
            View More Options
          </Button>
        </>
      )}
    </div>
  );
};

export default RidesTab;