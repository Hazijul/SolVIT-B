import { useState, useRef, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RidesTab from "./RidesTab";
import ParkingTab from "./ParkingTab";
import RoutesTab from "./RoutesTab";

type SheetState = "collapsed" | "partial" | "expanded";

interface BottomSheetProps {
  defaultState?: SheetState;
  expanded?: boolean;
  activeTab?: 'rides' | 'parking' | 'routes';
}

const BottomSheet = ({ 
  defaultState = "partial", 
  expanded = false, 
  activeTab = 'rides' 
}: BottomSheetProps) => {
  const [sheetState, setSheetState] = useState<SheetState>(expanded ? "expanded" : defaultState);
  const [currentTab, setCurrentTab] = useState(activeTab);
  const sheetRef = useRef<HTMLDivElement>(null);
  const handleRef = useRef<HTMLDivElement>(null);
  const draggingRef = useRef(false);
  const startYRef = useRef(0);
  const startTranslateYRef = useRef(0);

  const sheetStates = {
    collapsed: "85%",
    partial: "65%",
    expanded: "0%",
  };

  useEffect(() => {
    if (expanded) {
      setSheetState("expanded");
    }
  }, [expanded]);
  
  // Update currentTab when activeTab prop changes
  useEffect(() => {
    setCurrentTab(activeTab);
  }, [activeTab]);

  const getTranslateY = (element: HTMLElement): number => {
    const style = window.getComputedStyle(element);
    const transform = style.getPropertyValue("transform");

    if (transform === "none") {
      return 0;
    }

    const matrix = transform.match(/^matrix\((.+)\)$/);
    if (matrix) {
      const values = matrix[1].split(", ");
      return parseFloat(values[5]);
    }
    return 0;
  };

  const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
    if (!handleRef.current || !sheetRef.current) return;

    draggingRef.current = true;
    
    // Get client Y based on event type
    const clientY = 'touches' in e 
      ? e.touches[0].clientY 
      : e.clientY;
    
    startYRef.current = clientY;
    startTranslateYRef.current = getTranslateY(sheetRef.current);
    
    if (sheetRef.current) {
      sheetRef.current.style.transition = "none";
    }
  };

  const handleDrag = (e: React.MouseEvent | React.TouchEvent) => {
    if (!draggingRef.current || !sheetRef.current) return;

    // Get client Y based on event type
    const clientY = 'touches' in e 
      ? e.touches[0].clientY 
      : e.clientY;
    
    const deltaY = clientY - startYRef.current;
    let newTranslateY = startTranslateYRef.current + deltaY;

    const windowHeight = window.innerHeight;
    const maxTranslate = (parseFloat(sheetStates.collapsed.replace("%", "")) / 100) * windowHeight;
    const minTranslate = 0;

    newTranslateY = Math.max(minTranslate, Math.min(maxTranslate, newTranslateY));
    const translateYPercentage = (newTranslateY / windowHeight) * 100;

    sheetRef.current.style.transform = `translateY(${translateYPercentage}%)`;
  };

  const handleDragEnd = () => {
    if (!draggingRef.current || !sheetRef.current) return;

    draggingRef.current = false;
    if (sheetRef.current) {
      sheetRef.current.style.transition = "transform 0.3s ease-in-out";
    }

    const currentTranslate = getTranslateY(sheetRef.current);
    const windowHeight = window.innerHeight;

    const collapsedThreshold = (parseFloat(sheetStates.collapsed.replace("%", "")) / 100) * windowHeight * 0.8;
    const partialThreshold = (parseFloat(sheetStates.partial.replace("%", "")) / 100) * windowHeight * 0.8;

    if (currentTranslate > collapsedThreshold) {
      setSheetState("collapsed");
    } else if (currentTranslate > partialThreshold) {
      setSheetState("partial");
    } else {
      setSheetState("expanded");
    }
  };

  useEffect(() => {
    if (sheetRef.current) {
      sheetRef.current.style.transform = `translateY(${sheetStates[sheetState]})`;
    }
  }, [sheetState]);

  return (
    <div 
      ref={sheetRef}
      className="bottom-sheet bg-white rounded-t-2xl absolute bottom-0 left-0 right-0 z-20 shadow-lg transform transition-transform duration-300 ease-in-out"
      style={{ transform: `translateY(${sheetStates[sheetState]})` }}
    >
      <div 
        ref={handleRef}
        className="cursor-grab"
        onMouseDown={handleDragStart}
        onTouchStart={handleDragStart}
        onMouseMove={draggingRef.current ? handleDrag : undefined}
        onTouchMove={draggingRef.current ? handleDrag : undefined}
        onMouseUp={handleDragEnd}
        onTouchEnd={handleDragEnd}
        onMouseLeave={handleDragEnd}
      >
        <div className="w-10 h-1 bg-neutral-300 rounded-full mx-auto my-3"></div>
      </div>

      <Tabs defaultValue="rides" value={currentTab} onValueChange={(value) => setCurrentTab(value as 'rides' | 'parking' | 'routes')}>
        <div className="px-4 pt-2 pb-4">
          <TabsList className="w-full grid grid-cols-3 border-b border-neutral-200 bg-transparent">
            <TabsTrigger 
              value="rides" 
              className="data-[state=active]:text-primary data-[state=active]:font-medium relative transition-all duration-300 ease-in-out"
            >
              <span className="flex items-center justify-center space-x-1">
                <svg 
                  className="w-4 h-4 transition-transform duration-300 data-[state=active]:scale-110" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M13 10V3L4 14h7v7l9-11h-7z" 
                  />
                </svg>
                <span>Rides</span>
              </span>
              <div className="absolute bottom-0 left-0 right-0 bg-primary h-0.5 scale-x-0 transition-transform duration-300 data-[state=active]:scale-x-100"></div>
            </TabsTrigger>
            <TabsTrigger 
              value="parking" 
              className="data-[state=active]:text-primary data-[state=active]:font-medium relative transition-all duration-300 ease-in-out"
            >
              <span className="flex items-center justify-center space-x-1">
                <svg 
                  className="w-4 h-4 transition-transform duration-300 data-[state=active]:scale-110" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M8 7h8a2 2 0 012 2v10a2 2 0 01-2 2H8a2 2 0 01-2-2V9a2 2 0 012-2zm6 8a2 2 0 100-4 2 2 0 000 4z" 
                  />
                </svg>
                <span>Parking</span>
              </span>
              <div className="absolute bottom-0 left-0 right-0 bg-primary h-0.5 scale-x-0 transition-transform duration-300 data-[state=active]:scale-x-100"></div>
            </TabsTrigger>
            <TabsTrigger 
              value="routes" 
              className="data-[state=active]:text-primary data-[state=active]:font-medium relative transition-all duration-300 ease-in-out"
            >
              <span className="flex items-center justify-center space-x-1">
                <svg 
                  className="w-4 h-4 transition-transform duration-300 data-[state=active]:scale-110" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" 
                  />
                </svg>
                <span>Routes</span>
              </span>
              <div className="absolute bottom-0 left-0 right-0 bg-primary h-0.5 scale-x-0 transition-transform duration-300 data-[state=active]:scale-x-100"></div>
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="px-4 overflow-y-auto" style={{ maxHeight: '60vh' }}>
          <TabsContent 
            value="rides" 
            className="mt-0 transition-all duration-300 ease-in-out data-[state=inactive]:opacity-0 data-[state=active]:animate-in data-[state=inactive]:animate-out data-[state=active]:fade-in-0 data-[state=inactive]:fade-out-0 data-[state=inactive]:zoom-out-95 data-[state=active]:zoom-in-95"
          >
            <RidesTab />
          </TabsContent>
          <TabsContent 
            value="parking" 
            className="mt-0 transition-all duration-300 ease-in-out data-[state=inactive]:opacity-0 data-[state=active]:animate-in data-[state=inactive]:animate-out data-[state=active]:fade-in-0 data-[state=inactive]:fade-out-0 data-[state=inactive]:zoom-out-95 data-[state=active]:zoom-in-95"
          >
            <ParkingTab />
          </TabsContent>
          <TabsContent 
            value="routes" 
            className="mt-0 transition-all duration-300 ease-in-out data-[state=inactive]:opacity-0 data-[state=active]:animate-in data-[state=inactive]:animate-out data-[state=active]:fade-in-0 data-[state=inactive]:fade-out-0 data-[state=inactive]:zoom-out-95 data-[state=active]:zoom-in-95"
          >
            <RoutesTab />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

// Animation for button clicks
export const animateSuccess = (element: HTMLElement | null) => {
  if (!element) return;
  
  element.classList.add('animation-success');
  
  setTimeout(() => {
    element.classList.remove('animation-success');
  }, 1000);
};

export const animateLoading = (element: HTMLElement | null) => {
  if (!element) return;
  
  // Add loading class
  element.classList.add('animation-loading');
  element.setAttribute('disabled', 'true');
  
  const originalText = element.innerHTML;
  element.innerHTML = `
    <div class="flex items-center justify-center">
      <svg class="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
      Processing...
    </div>
  `;
  
  // Set timeout to restore original state
  setTimeout(() => {
    element.classList.remove('animation-loading');
    element.removeAttribute('disabled');
    element.innerHTML = originalText;
  }, 2000);
};

export default BottomSheet;
