import { Bell, User } from "lucide-react";
import { Button } from "@/components/ui/button";

const Header = () => {
  return (
    <header className="bg-white shadow-sm z-20 relative">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"></path>
          </svg>
          <h1 className="text-xl font-bold text-neutral-800 ml-2">NaviSense</h1>
        </div>
        <div className="flex items-center">
          <Button variant="ghost" size="icon" aria-label="Notifications">
            <Bell className="h-5 w-5 text-neutral-600" />
          </Button>
          <Button variant="ghost" size="icon" className="ml-2" aria-label="User Profile">
            <User className="h-5 w-5 text-neutral-600" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
