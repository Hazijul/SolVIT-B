import { Car, Leaf, Bus } from "lucide-react";
import { Button } from "@/components/ui/button";

interface QuickAction {
  id: string;
  icon: React.ReactNode;
  label: string;
  color: string;
}

interface QuickActionsProps {
  onActionClick: (action: string) => void;
}

const QuickActions = ({ onActionClick }: QuickActionsProps) => {
  const quickActions: QuickAction[] = [
    {
      id: "carpools",
      icon: <Car className="mr-2 h-4 w-4 text-primary" />,
      label: "Carpools",
      color: "text-primary",
    },
    {
      id: "parking",
      icon: (
        <svg className="mr-2 h-4 w-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h8a2 2 0 012 2v10a2 2 0 01-2 2H8a2 2 0 01-2-2V9a2 2 0 012-2zm6 8a2 2 0 100-4 2 2 0 000 4z" />
        </svg>
      ),
      label: "Parking",
      color: "text-green-500",
    },
    {
      id: "ecoRoutes",
      icon: <Leaf className="mr-2 h-4 w-4 text-green-600" />,
      label: "Eco Routes",
      color: "text-green-600",
    },
    {
      id: "transit",
      icon: <Bus className="mr-2 h-4 w-4 text-blue-500" />,
      label: "Transit",
      color: "text-blue-500",
    },
  ];

  return (
    <div className="absolute top-32 left-4 right-4 z-10 flex space-x-2 overflow-x-auto py-2 px-1">
      {quickActions.map((action) => (
        <Button
          key={action.id}
          variant="outline"
          className="flex-shrink-0 bg-white px-4 py-2 rounded-full text-sm font-medium text-neutral-700 shadow-md border border-neutral-100 flex items-center"
          onClick={() => onActionClick(action.id)}
        >
          {action.icon}
          {action.label}
        </Button>
      ))}
    </div>
  );
};

export default QuickActions;
