import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, Shield } from 'lucide-react';

interface ParkingSpot {
  id: number;
  name: string;
  hourlyRate: number;
  distance: string;
  availableSpots: number;
  features: string[];
  restrictions: string;
}

const ParkingTab = () => {
  const [location, setLocation] = useState('Downtown Business District');
  const [reservableOnly, setReservableOnly] = useState(false);
  const [maxPrice, setMaxPrice] = useState('10');
  
  const { data: parkingSpots, isLoading } = useQuery({
    queryKey: ['/api/parking-spots'],
    enabled: true,
  });
  
  // Fallback parking data
  const fallbackParkingSpots: ParkingSpot[] = [
    {
      id: 1,
      name: 'Central Garage',
      hourlyRate: 450, // In cents, $4.50
      distance: '0.2 miles',
      availableSpots: 8,
      features: ['24/7 access', 'Secure'],
      restrictions: '24/7 access'
    },
    {
      id: 2,
      name: 'Street Parking - Main St',
      hourlyRate: 200, // $2.00
      distance: '0.1 miles',
      availableSpots: 3,
      features: ['2hr limit', 'Until 6PM'],
      restrictions: '2hr limit, until 6PM'
    }
  ];
  
  // Use actual data or fallback
  const displayParkingSpots = parkingSpots || fallbackParkingSpots;
  
  const formatPrice = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}/hr`;
  };
  
  const handleFindParking = () => {
    // In a real app, this would call an API to find parking spots based on preferences
    console.log('Finding parking near:', location);
    console.log('Reservable only:', reservableOnly);
    console.log('Max price:', maxPrice);
  };
  
  const handleReserveSpot = (spotId: number) => {
    // In a real app, this would call an API to reserve a parking spot
    console.log(`Reserving parking spot ${spotId}`);
  };
  
  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold mb-3">Smart Parking Finder</h3>
      
      {/* Parking Search */}
      <div className="bg-neutral-50 rounded-lg p-4 mb-4">
        <h4 className="text-sm font-medium text-neutral-500 mb-2">Find Parking Near</h4>
        <div className="relative mb-3">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg className="h-4 w-4 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <Input
            type="text"
            className="w-full pl-10 pr-4 py-2"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Enter location"
          />
        </div>
        
        {/* Parking Filters */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <Checkbox 
              id="reservable" 
              checked={reservableOnly}
              onCheckedChange={(checked) => setReservableOnly(checked === true)}
            />
            <Label htmlFor="reservable" className="ml-2 text-sm text-neutral-600">
              Reservable only
            </Label>
          </div>
          <div className="flex items-center">
            <span className="text-sm text-neutral-600 mr-2">Max price:</span>
            <Select value={maxPrice} onValueChange={setMaxPrice}>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">$5/hr</SelectItem>
                <SelectItem value="10">$10/hr</SelectItem>
                <SelectItem value="15">$15/hr</SelectItem>
                <SelectItem value="999">Any</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Button 
          className="w-full bg-green-500 hover:bg-green-600 text-white" 
          onClick={handleFindParking}
        >
          Find Parking
        </Button>
      </div>
      
      {/* Available Parking Spots */}
      <h4 className="text-base font-medium mb-3">Available Parking Spots</h4>
      
      {isLoading ? (
        <div className="space-y-3">
          <div className="bg-neutral-100 h-28 rounded-lg animate-pulse"></div>
          <div className="bg-neutral-100 h-28 rounded-lg animate-pulse"></div>
        </div>
      ) : (
        <>
          {displayParkingSpots.map((spot) => (
            <div key={spot.id} className="bg-white border border-neutral-200 rounded-lg p-4 mb-3 hover:shadow-md transition-shadow">
              <div className="flex items-start">
                <div className="bg-green-100 rounded-full p-2 mr-3">
                  <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <h5 className="font-medium">{spot.name}</h5>
                    <span className="text-sm font-medium text-green-500">{formatPrice(spot.hourlyRate)}</span>
                  </div>
                  <p className="text-sm text-neutral-600 mb-1">
                    {spot.distance} away • {spot.availableSpots} spots available
                  </p>
                  <div className="flex items-center text-xs text-neutral-500 mb-2">
                    {spot.features.map((feature, index) => (
                      <span key={index} className="flex items-center mr-3">
                        {index === 0 ? (
                          <Clock className="h-3 w-3 mr-1" />
                        ) : (
                          <Shield className="h-3 w-3 mr-1" />
                        )}
                        {feature}
                      </span>
                    ))}
                  </div>
                  <Button 
                    className="w-full mt-2 bg-green-500 hover:bg-green-600 text-white" 
                    onClick={() => handleReserveSpot(spot.id)}
                  >
                    {spot.id === 1 ? 'Reserve Spot' : 'Navigate Here'}
                  </Button>
                </div>
              </div>
            </div>
          ))}
          
          <Button variant="ghost" className="w-full py-3 text-green-500 font-medium">
            Show More Spots
          </Button>
        </>
      )}
    </div>
  );
};

export default ParkingTab;
