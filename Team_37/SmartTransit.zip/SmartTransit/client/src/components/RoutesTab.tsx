import { useState, useRef, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, Bike, Battery, Leaf, ChevronDown, ChevronUp, ZapOff, Zap, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RouteSegment {
  type: string;
  duration: number;
  hasChargingStation?: boolean;
}

interface Route {
  id: number;
  name: string;
  duration: number;
  distance: number;
  arrivalTime: string;
  co2Reduction: number;
  segments: RouteSegment[];
}

const RoutesTab = () => {
  const [origin, setOrigin] = useState('Current Location');
  const [destination, setDestination] = useState('');
  const [routePreference, setRoutePreference] = useState('eco');
  const [vehicleType, setVehicleType] = useState('gas');
  const [isPlannerExpanded, setIsPlannerExpanded] = useState(true);
  const [isRoutesExpanded, setIsRoutesExpanded] = useState(true);
  const plannerRef = useRef<HTMLDivElement>(null);
  const plannerContentRef = useRef<HTMLDivElement>(null);
  const routesRef = useRef<HTMLDivElement>(null);
  const routesContentRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);


  const { data: routeSuggestions, refetch } = useQuery({
    queryKey: ['/api/route-suggestions', origin, destination, routePreference],
    enabled: false, 
  });

  const fallbackRoutes: Route[] = [
    {
      id: 1,
      name: 'Hybrid Route',
      duration: 25,
      distance: 7.2, 
      arrivalTime: '8:32 AM',
      co2Reduction: 45,
      segments: [
        { type: 'walk', duration: 5 },
        { type: 'bus', duration: 15 },
        { type: 'walk', duration: 5 }
      ]
    },
    {
      id: 2,
      name: 'EV-Optimized Route',
      duration: 32,
      distance: 8.3, 
      arrivalTime: '8:39 AM',
      co2Reduction: 100,
      segments: [
        { type: 'ev', duration: 32, hasChargingStation: true }
      ]
    }
  ];

  const displayRoutes = routeSuggestions || fallbackRoutes;

  const handleFindRoutes = () => {
    setIsLoading(true);
    setShowResults(false);
    setTimeout(() => {
      setIsLoading(false);
      setShowResults(true);
      refetch();
    }, 1500);
  };

  const handleStartNavigation = (routeId: number, e: React.MouseEvent<HTMLButtonElement>) => {
    const button = e.currentTarget;
    button.classList.add('animation-loading');
    button.setAttribute('disabled', 'true');
    const originalText = button.innerHTML;
    button.innerHTML = `
      <div class="flex items-center justify-center">
        <svg class="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        Starting navigation...
      </div>
    `;

    console.log(`Starting navigation for route ${routeId}`);

    setTimeout(() => {
      button.classList.remove('animation-loading');
      button.removeAttribute('disabled');
      button.innerHTML = originalText;
      button.classList.add('ticket-confirm-animation');
      setTimeout(() => {
        button.classList.remove('ticket-confirm-animation');
      }, 1000);
    }, 2000);
  };

  useEffect(() => {
    if (plannerRef.current && plannerContentRef.current) {
      if (isPlannerExpanded) {
        plannerRef.current.style.height = `${plannerContentRef.current.scrollHeight}px`;
      } else {
        plannerRef.current.style.height = '56px'; 
      }
    }
  }, [isPlannerExpanded, destination, routePreference, vehicleType]);

  useEffect(() => {
    if (routesRef.current && routesContentRef.current) {
      if (isRoutesExpanded) {
        routesRef.current.style.height = `${routesContentRef.current.scrollHeight}px`;
      } else {
        routesRef.current.style.height = '40px'; 
      }
    }
  }, [isRoutesExpanded, displayRoutes, isLoading]);

  const togglePlanner = () => {
    setIsPlannerExpanded(!isPlannerExpanded);
  };

  const toggleRoutes = () => {
    setIsRoutesExpanded(!isRoutesExpanded);
  };

  const getSegmentIcon = (type: string) => {
    switch (type) {
      case 'walk':
        return <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7a4 4 0 11-8 0 4 4 0 018 0zM9 14a6 6 0 00-6 6v1h12v-1a6 6 0 00-6-6zM21 12h-6" />
        </svg>;
      case 'bus':
        return <svg className="h-3 w-3 text-blue-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
        </svg>;
      case 'ev':
        return <svg className="h-3 w-3 text-green-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>;
      default:
        return null;
    }
  };

  return (
    <div className="mb-6">
      <div className="bg-white border border-neutral-200 rounded-lg shadow-sm mb-4 overflow-hidden transition-all">
        <div 
          className={cn(
            "bg-gradient-to-r from-blue-600 to-green-500 p-4 flex items-center justify-between cursor-pointer transition-all duration-300 hover:from-blue-700 hover:to-green-600",
            isPlannerExpanded ? "rounded-t-lg" : "rounded-lg shadow-lg"
          )} 
          onClick={togglePlanner}
        >
          <div className="flex items-center">
            <div className={cn(
              "bg-white/30 rounded-full p-2 mr-3 transition-all duration-300 shadow-inner",
              isPlannerExpanded ? "" : "animate-pulse glow-animation"
            )}>
              <Zap className={cn(
                "h-6 w-6 text-white transition-transform duration-300",
                isPlannerExpanded ? "" : "rotate-45 animate-pulse"
              )} />
            </div>
            <h3 className="text-xl font-bold text-white drop-shadow-md">Energy-Efficient Route Planner</h3>
          </div>

          <div className="transition-transform duration-300 transform">
            {isPlannerExpanded ? (
              <ChevronUp className="h-6 w-6 text-white bg-white/20 rounded-full p-1" />
            ) : (
              <ChevronDown className="h-6 w-6 text-white bg-white/20 rounded-full p-1 animate-bounce" />
            )}
          </div>
        </div>

        <div
          ref={plannerRef}
          className="transition-all duration-500 ease-in-out overflow-hidden"
          style={{ height: isPlannerExpanded ? 'auto' : '56px' }}
        >
          <div ref={plannerContentRef} className="p-4">
            <h4 className="text-sm font-medium text-neutral-500 mb-2">Plan Your Journey</h4>

            <div className="relative mb-4 transform transition-all duration-300 hover:scale-[1.01] group">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <div className="w-5 h-5 rounded-full bg-blue-500 border-2 border-white group-hover:animate-pulse"></div>
              </div>
              <Input
                type="text"
                className="w-full pl-11 pr-4 py-2.5 focus:ring-2 focus:ring-blue-500/50 transition-all shadow-sm hover:shadow group-hover:border-blue-300"
                value={origin}
                onChange={(e) => setOrigin(e.target.value)}
                placeholder="Starting point"
              />
            </div>

            <div className="relative mb-4 transform transition-all duration-300 hover:scale-[1.01] group">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <div className="w-5 h-5 rounded-full bg-green-500 border-2 border-white group-hover:animate-pulse"></div>
              </div>
              <Input
                type="text"
                className="w-full pl-11 pr-4 py-2.5 focus:ring-2 focus:ring-green-500/50 transition-all shadow-sm hover:shadow group-hover:border-green-300"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="Destination"
              />
            </div>

            <h4 className="text-sm font-medium text-neutral-500 mt-4 mb-2">Route Preferences</h4>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <Button 
                variant={routePreference === 'eco' ? 'secondary' : 'outline'}
                className={cn(
                  "py-2 px-3 transition-all duration-300 transform hover:scale-[1.02]",
                  routePreference === 'eco' 
                    ? "bg-green-50 border-green-200 text-green-700 shadow-inner" 
                    : "hover:bg-green-50/50"
                )}
                onClick={() => setRoutePreference('eco')}
              >
                <Leaf className="mr-2 h-4 w-4" /> Eco-Friendly
              </Button>
              <Button 
                variant={routePreference === 'fastest' ? 'secondary' : 'outline'}
                className={cn(
                  "py-2 px-3 transition-all duration-300 transform hover:scale-[1.02]",
                  routePreference === 'fastest' 
                    ? "bg-green-50 border-green-200 text-green-700 shadow-inner" 
                    : "hover:bg-green-50/50"
                )}
                onClick={() => setRoutePreference('fastest')}
              >
                <Clock className="mr-2 h-4 w-4" /> Fastest
              </Button>
              <Button 
                variant={routePreference === 'fuelEfficient' ? 'secondary' : 'outline'}
                className={cn(
                  "py-2 px-3 transition-all duration-300 transform hover:scale-[1.02]",
                  routePreference === 'fuelEfficient' 
                    ? "bg-green-50 border-green-200 text-green-700 shadow-inner" 
                    : "hover:bg-green-50/50"
                )}
                onClick={() => setRoutePreference('fuelEfficient')}
              >
                <svg className="mr-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg> Fuel Efficient
              </Button>
              <Button 
                variant={routePreference === 'multiModal' ? 'secondary' : 'outline'}
                className={cn(
                  "py-2 px-3 transition-all duration-300 transform hover:scale-[1.02]",
                  routePreference === 'multiModal' 
                    ? "bg-green-50 border-green-200 text-green-700 shadow-inner" 
                    : "hover:bg-green-50/50"
                )}
                onClick={() => setRoutePreference('multiModal')}
              >
                <Bike className="mr-2 h-4 w-4" /> Multi-Modal
              </Button>
            </div>

            <div className="flex items-center mb-3 transition-all duration-300 hover:bg-neutral-50 p-1 rounded-md">
              <span className="text-sm text-neutral-600 mr-2">Vehicle type:</span>
              <Select value={vehicleType} onValueChange={setVehicleType}>
                <SelectTrigger className="flex-1 transition-all focus:ring-2 focus:ring-primary/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gas">Gas Car</SelectItem>
                  <SelectItem value="hybrid">Hybrid</SelectItem>
                  <SelectItem value="electric">Electric Vehicle</SelectItem>
                  <SelectItem value="none">No Vehicle</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              className="w-full bg-gradient-to-r from-blue-600 to-green-500 hover:from-blue-700 hover:to-green-600 text-white shadow-md hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] gradient-animation glow-animation" 
              onClick={handleFindRoutes}
              disabled={!destination || isLoading}
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="loading-spinner mr-2" /> {/* Assume loading-spinner component exists */}
                  Finding Routes...
                </div>
              ) : (
                <>
                  <Zap className="h-5 w-5 mr-2 animate-pulse" />
                  Find Smart Routes
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-white border border-neutral-200 rounded-lg shadow-sm overflow-hidden transition-all">
        <div 
          className={cn(
            "p-3 flex items-center justify-between cursor-pointer bg-gradient-to-r from-blue-500/10 to-green-500/10 border-b",
            isRoutesExpanded ? "border-neutral-200" : "border-transparent"
          )} 
          onClick={toggleRoutes}
        >
          <h4 className="text-base font-semibold flex items-center text-blue-700">
            <div className="bg-blue-100 rounded-full p-1.5 mr-2">
              <MapPin className="h-4 w-4 text-blue-600" />
            </div>
            Suggested Smart Routes
          </h4>

          <div className="transition-transform duration-300 transform">
            {isRoutesExpanded ? (
              <ChevronUp className="h-5 w-5 text-blue-500" />
            ) : (
              <ChevronDown className="h-5 w-5 text-blue-500 animate-bounce" />
            )}
          </div>
        </div>

        <div
          ref={routesRef}
          className={`transition-all duration-300 ease-in-out overflow-hidden ${isRoutesExpanded ? 'slide-down' : 'slide-up'}`}
          style={{ height: isRoutesExpanded ? 'auto' : '0px' }}
        >
          <div ref={routesContentRef} className="p-4">
            {isLoading ? (
              <div className="space-y-4">
                <div className="bg-neutral-100 h-32 rounded-lg animate-pulse"></div>
                <div className="bg-neutral-100 h-32 rounded-lg animate-pulse" style={{animationDelay: '0.2s'}}></div>
              </div>
            ) : (
              <>
                {showResults && (
                  <div className="animate-slide-down"> {/* Assume animate-slide-down class exists */}
                    {displayRoutes.map((route, idx) => (
                      <div 
                        key={route.id} 
                        className="bg-white border border-neutral-200 rounded-lg p-4 mb-3 hover:shadow-lg transition-all duration-500 hover:border-blue-300 scale-up"
                        style={{animationDelay: `${idx * 0.15}s`}}
                      >
                        <div className="flex items-start">
                          <div className={cn(
                            "rounded-full p-2 mr-3 transition-all duration-500",
                            route.co2Reduction > 80 
                              ? "bg-green-100" 
                              : route.co2Reduction > 40 
                                ? "bg-amber-100" 
                                : "bg-blue-100"
                          )}>
                            <svg 
                              className={cn(
                                "h-5 w-5 transition-all duration-500",
                                route.co2Reduction > 80 
                                  ? "text-green-600" 
                                  : route.co2Reduction > 40 
                                    ? "text-amber-600" 
                                    : "text-blue-600"
                              )} 
                              fill="none" 
                              stroke="currentColor" 
                              viewBox="0 0 24 24" 
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                            </svg>
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between mb-1">
                              <h5 className="font-medium">{route.name}</h5>
                              <div className="flex items-center">
                                <span className={cn(
                                  "text-xs px-2 py-0.5 rounded-full font-medium transition-all duration-500",
                                  route.co2Reduction > 80 
                                    ? "bg-green-100 text-green-800" 
                                    : route.co2Reduction > 40 
                                      ? "bg-amber-100 text-amber-800" 
                                      : "bg-blue-100 text-blue-800"
                                )}>
                                  -{route.co2Reduction}% CO₂
                                </span>
                              </div>
                            </div>
                            <p className="text-sm text-neutral-600 mb-1">
                              {route.duration} mins • {route.distance.toFixed(1)} km • Arrives {route.arrivalTime}
                            </p>

                            <div className="flex items-center text-xs space-x-1 text-neutral-500 mb-2">
                              {route.segments.map((segment, index) => (
                                <div 
                                  key={index} 
                                  className="flex items-center transition-all duration-300 hover:scale-105"
                                >
                                  {index > 0 && (
                                    <svg className="h-3 w-3 mx-1 text-neutral-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                    </svg>
                                  )}
                                  <span className={cn(
                                    "p-1 rounded flex items-center transition-all duration-300",
                                    segment.type === 'bus' 
                                      ? "bg-blue-100 text-blue-700 hover:bg-blue-200" 
                                      : segment.type === 'ev' 
                                        ? "bg-green-100 text-green-700 hover:bg-green-200" 
                                        : "bg-neutral-100 hover:bg-neutral-200"
                                  )}>
                                    {getSegmentIcon(segment.type)} 
                                    <span className="ml-1">{segment.duration}min</span>
                                  </span>
                                  {segment.hasChargingStation && (
                                    <span className="ml-1 text-neutral-500 flex items-center">
                                      <Zap className="h-3 w-3 text-amber-500 mr-1" /> Charging
                                    </span>
                                  )}
                                </div>
                              ))}
                            </div>

                            <Button 
                              className="w-full mt-2 bg-gradient-to-r from-blue-600 to-green-500 hover:from-blue-700 hover:to-green-600 text-white shadow-md hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] gradient-animation glow-animation" 
                              onClick={() => handleStartNavigation(route.id)}
                            >
                              <MapPin className="h-4 w-4 mr-2" /> Start Navigation
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                    <Button 
                      variant="ghost" 
                      className="w-full py-3 text-green-600 font-medium hover:bg-green-50 transition-all duration-300"
                    >
                      View More Routes
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoutesTab;