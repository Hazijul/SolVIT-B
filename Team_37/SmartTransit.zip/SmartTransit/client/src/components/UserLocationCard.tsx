import { useState, useRef, useEffect } from "react";
import { MapPin, Search, X, Clock, Star, Navigation, Home, Building, Coffee, BookmarkIcon, Locate } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

async function getAddressFromCoords(lat: number, lng: number) {
  try {
    const response = await fetch(`https://us1.locationiq.com/v1/reverse.php?key=${process.env.LOCATION_IQ_API}&lat=${lat}&lon=${lng}&format=json`);
    const data = await response.json();
    return data.display_name || "Location not found";
  } catch (error) {
    console.error("Error getting address:", error);
    return "Location not found";
  }
}

interface UserLocationCardProps {
  userLocation: string;
  onDestinationFocus: () => void;
}

const UserLocationCard = ({ userLocation, onDestinationFocus }: UserLocationCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isEditingLocation, setIsEditingLocation] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSearchFocus = () => {
    setIsExpanded(true);
    onDestinationFocus();
  };

  const handleSearchBlur = () => {
    if (!showSuggestions) {
      setIsExpanded(false);
    }
  };

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
    setShowSuggestions(true);
  };

  const handleClearSearch = () => {
    setSearchValue("");
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleLocationEdit = () => {
    setIsEditingLocation(true);
  };

  return (
    <div className="absolute top-4 left-4 right-4 z-10">
      <div className={cn(
        "bg-white rounded-lg shadow-lg transition-all duration-300",
        isExpanded ? "p-0" : "p-4"
      )}>
        <div className="p-2 flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            className="border-none shadow-none hover:bg-neutral-100 p-2 h-auto transition-all duration-200"
            onClick={() => {
              setIsExpanded(false);
              setShowSuggestions(false);
            }}
          >
            <X className="h-5 w-5 text-neutral-500" />
          </Button>

          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center text-xs transition-all duration-200 hover:bg-neutral-100"
            >
              <BookmarkIcon className="h-4 w-4 mr-1" />
              Save
            </Button>
            <Button
              variant="default"
              size="sm"
              className="flex items-center text-xs bg-primary hover:bg-primary/90 shadow-md hover:shadow-lg transition-all duration-200"
            >
              <Navigation className="h-4 w-4 mr-1" />
              Directions
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserLocationCard;