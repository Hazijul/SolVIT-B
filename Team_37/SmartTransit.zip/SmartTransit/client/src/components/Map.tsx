import { useState, useEffect, useRef, useCallback } from 'react';
import { MapPin, Car, Bus, Search, Loader, Plus, Minus } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Button } from '@/components/ui/button';
import { cn } from "@/lib/utils";

interface MapMarker {
  id: string;
  type: 'user' | 'parking' | 'carpool' | 'transit';
  position: [number, number]; // [latitude, longitude]
  title?: string;
  description?: string;
}

interface MapProps {
  onMarkerClick?: (markerId: string, position: [number, number]) => void;
}

const Map = ({ onMarkerClick }: MapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<L.Map | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const markersRef = useRef<L.Marker[]>([]);
  const [userPosition, setUserPosition] = useState<[number, number]>([37.7749, -122.4194]); // Default: San Francisco
  
  // Sample markers - in a real app would come from an API/backend
  const [markers] = useState<MapMarker[]>([
    { 
      id: 'user', 
      type: 'user', 
      position: userPosition,
      title: 'Your Location'
    },
    { 
      id: 'parking1', 
      type: 'parking', 
      position: [37.7739, -122.4312],
      title: 'Downtown Parking',
      description: '24 spots available • $3.50/hr' 
    },
    { 
      id: 'carpool1', 
      type: 'carpool', 
      position: [37.7819, -122.4159],
      title: 'Carpool Station',
      description: '3 rides available'
    },
    { 
      id: 'transit1', 
      type: 'transit', 
      position: [37.7699, -122.4148],
      title: 'Bus Stop #42',
      description: 'Lines: 5, 22, 33'
    },
  ]);

  // Get user's location
  const getUserLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserPosition([latitude, longitude]);
          
          // Update the map view
          if (leafletMap.current) {
            leafletMap.current.setView([latitude, longitude], 15);
            
            // Update user marker position
            markersRef.current.forEach(marker => {
              if (marker.options.title === 'Your Location') {
                marker.setLatLng([latitude, longitude]);
              }
            });
          }
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, []);

  useEffect(() => {
    // Initialize map only if it doesn't exist yet
    if (mapRef.current && !leafletMap.current) {
      setIsLoading(true);
      
      // Create map
      leafletMap.current = L.map(mapRef.current, {
        zoomControl: false, // We'll add this in a custom position
        attributionControl: true
      }).setView(userPosition, 14);
      
      // Add OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(leafletMap.current);
      
      // Add zoom control to the top right
      L.control.zoom({
        position: 'topright'
      }).addTo(leafletMap.current);

      // Add markers
      markers.forEach(marker => {
        const icon = createCustomIcon(marker.type);
        const leafletMarker = L.marker(marker.position, { 
          icon,
          title: marker.title
        }).addTo(leafletMap.current!);
        
        // Add marker to refs array for later access
        markersRef.current.push(leafletMarker);
        
        // Add popup if title/description exists
        if (marker.title || marker.description) {
          const popupContent = `
            <div class="font-medium">${marker.title || ''}</div>
            ${marker.description ? `<div class="text-xs text-neutral-600">${marker.description}</div>` : ''}
          `;
          leafletMarker.bindPopup(popupContent);
        }
        
        // Add click handler
        leafletMarker.on('click', () => {
          if (onMarkerClick) {
            onMarkerClick(marker.id, marker.position);
          }
        });
      });
      
      setIsLoading(false);
      
      // Try to get user's location
      getUserLocation();
    }

    // Cleanup function
    return () => {
      if (leafletMap.current) {
        leafletMap.current.remove();
        leafletMap.current = null;
        markersRef.current = [];
      }
    };
  }, []); // Empty dependency array ensures this runs once

  // Function to create custom icons for each marker type
  const createCustomIcon = (type: string): L.DivIcon => {
    let className = '';
    let html = '';

    switch (type) {
      case 'user':
        className = 'bg-primary';
        html = '<div class="flex items-center justify-center h-full w-full"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg></div>';
        break;
      case 'parking':
        className = 'bg-green-500';
        html = '<div class="flex items-center justify-center h-full w-full"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 7h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z"></path><path d="M14 15a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"></path></svg></div>';
        break;
      case 'carpool':
        className = 'bg-amber-500';
        html = '<div class="flex items-center justify-center h-full w-full"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.6-1.2-.9-1.9-1L9 6c-.9 0-1.7.5-2.2 1.3L6 8"></path><path d="M9 17h6"></path><path d="M13 17v2.4"></path><path d="M11 17v2.4"></path><path d="M4 17h2"></path><path d="M2 5h11"></path><path d="M2 8h7"></path><path d="M2 11h4"></path><path d="M19 19h2c.6 0 1-.4 1-1"></path><path d="M4 19h2c.6 0 1-.4 1-1"></path><path d="M18 13h1c.6 0 1 .4 1 1v1"></path><path d="M6 13H5c-.6 0-1 .4-1 1v1"></path><circle cx="4" cy="17" r="2"></circle><circle cx="20" cy="17" r="2"></circle></svg></div>';
        break;
      case 'transit':
        className = 'bg-primary';
        html = '<div class="flex items-center justify-center h-full w-full"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 5H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-3"></path><path d="M19 17h2v4"></path><path d="M5 17H3v4"></path><path d="M15 5H9a1 1 0 0 0-1 1v1h8V6a1 1 0 0 0-1-1Z"></path><path d="M9 15v-5"></path><path d="M9 14h6"></path><path d="M15 15v-5"></path></svg></div>';
        break;
      default:
        className = 'bg-gray-500';
        html = '';
    }

    // Add Leaflet CSS classes
    return L.divIcon({
      className: `leaflet-div-icon marker-${type}`,
      html: `<div class="h-6 w-6 ${className} rounded-full border-2 border-white shadow-lg flex items-center justify-center">${html}</div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });
  };

  // Locate user
  const handleLocateUser = () => {
    getUserLocation();
  };

  const [locatingUser, setLocatingUser] = useState(false);
  const [searchInputFocused, setSearchInputFocused] = useState(false);
  
  const handleZoomIn = () => {
    if (leafletMap.current) {
      leafletMap.current.zoomIn();
    }
  };
  
  const handleZoomOut = () => {
    if (leafletMap.current) {
      leafletMap.current.zoomOut();
    }
  };
  
  // Enhanced user location with animation
  const handleLocateUserEnhanced = () => {
    setLocatingUser(true);
    getUserLocation();
    
    // Add pulsing animation to user marker
    setTimeout(() => {
      markersRef.current.forEach(marker => {
        if (marker.options.title === 'Your Location') {
          const icon = marker.getElement();
          if (icon) {
            icon.classList.add('pulse-animation');
            setTimeout(() => {
              icon.classList.remove('pulse-animation');
              setLocatingUser(false);
            }, 3000);
          } else {
            setLocatingUser(false);
          }
        }
      });
    }, 500);
  };

  return (
    <div className="absolute inset-0 z-0">
      <div ref={mapRef} className="h-full w-full"></div>
      
      {/* Custom zoom controls */}
      <div className="absolute right-4 top-32 z-10 flex flex-col space-y-2">
        <Button 
          size="icon" 
          variant="outline" 
          className="h-10 w-10 rounded-full bg-white shadow-md hover:shadow-lg transition-all duration-200"
          onClick={handleZoomIn}
        >
          <Plus className="h-5 w-5" />
        </Button>
        <Button 
          size="icon" 
          variant="outline" 
          className="h-10 w-10 rounded-full bg-white shadow-md hover:shadow-lg transition-all duration-200"
          onClick={handleZoomOut}
        >
          <Minus className="h-5 w-5" />
        </Button>
      </div>
      
      {/* Location button with loading animation */}
      <div className="absolute bottom-32 right-4 z-10">
        <Button 
          size="icon" 
          variant="outline" 
          className={cn(
            "h-10 w-10 rounded-full bg-white shadow-md hover:shadow-lg transition-all duration-300",
            locatingUser && "bg-primary/10"
          )}
          onClick={handleLocateUserEnhanced}
          disabled={locatingUser}
        >
          {locatingUser ? (
            <Loader className="h-5 w-5 text-primary animate-spin" />
          ) : (
            <MapPin className="h-5 w-5" />
          )}
        </Button>
      </div>
      
      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/20 flex items-center justify-center z-20">
          <div className="bg-white p-6 rounded-lg shadow-xl text-center">
            <div className="animate-spin rounded-full h-10 w-10 border-4 border-neutral-200 border-t-primary mx-auto"></div>
            <p className="text-center mt-4 font-medium">Loading map...</p>
            <p className="text-sm text-neutral-500 mt-1">Please wait while we prepare your navigation experience</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Map;
