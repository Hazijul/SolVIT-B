import { useLocation } from 'wouter';
import { Home, Map, History, User } from 'lucide-react';
import { cn } from "@/lib/utils";

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

const MobileNavBar = () => {
  const [location] = useLocation();
  
  const navItems: NavItem[] = [
    { path: '/', label: 'Home', icon: <Home className="text-xl" /> },
    { path: '/explore', label: 'Explore', icon: <Map className="text-xl" /> },
    { path: '/history', label: 'History', icon: <History className="text-xl" /> },
    { path: '/profile', label: 'Profile', icon: <User className="text-xl" /> },
  ];

  const handleNavigation = (path: string) => {
    // Using window.location to prevent nested anchor tag issues
    window.location.href = path;
  };

  return (
    <nav className="bg-white border-t border-neutral-200 fixed bottom-0 left-0 right-0 z-30 md:hidden shadow-lg">
      <div className="grid grid-cols-4 h-16">
        {navItems.map((item) => (
          <div 
            key={item.path} 
            onClick={() => handleNavigation(item.path)}
            className={cn(
              "flex flex-col items-center justify-center cursor-pointer transition-all duration-200 relative nav-link",
              location === item.path ? "text-primary active" : "text-neutral-400 hover:text-neutral-600"
            )}
          >
            <div className={cn(
              "transition-all duration-300 ease-in-out",
              location === item.path && "transform scale-110"
            )}>
              {item.icon}
            </div>
            <span className={cn(
              "text-xs mt-1 transition-all duration-300 ease-in-out",
              location === item.path && "font-medium"
            )}>
              {item.label}
            </span>
            
            {/* Active indicator */}
            {location === item.path && (
              <span className="absolute -bottom-0 w-12 h-0.5 bg-primary rounded-full pulse-animation" />
            )}
          </div>
        ))}
      </div>
    </nav>
  );
};

export default MobileNavBar;
