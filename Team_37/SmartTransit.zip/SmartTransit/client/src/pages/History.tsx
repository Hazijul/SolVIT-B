import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Header from '@/components/Header';
import MobileNavBar from '@/components/MobileNavBar';
import DesktopSidebar from '@/components/DesktopSidebar';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { 
  Calendar as CalendarIcon, 
  Car, 
  Bike, 
  Bus, 
  Leaf, 
  Clock, 
  DollarSign,
  MapPin,
  BarChart4
} from 'lucide-react';

interface TripHistoryItem {
  id: number;
  origin: string;
  destination: string;
  transportType: 'carpool' | 'bus' | 'walk' | 'bike' | 'ev';
  startTime: Date;
  endTime: Date;
  distance: number;
  cost: number;
  co2Saved: number;
}

const History = () => {
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [filterType, setFilterType] = useState("all");
  
  // Fetch trip history from API
  const { data: tripHistory, isLoading } = useQuery({
    queryKey: ['/api/trip-history/user/1'], // Assuming user ID 1 for now
    enabled: true,
  });
  
  // Mock data until real data is available
  const fallbackTripHistory: TripHistoryItem[] = [
    {
      id: 1,
      origin: "123 Main Street, City Center",
      destination: "456 Business District",
      transportType: "carpool",
      startTime: new Date(2023, 8, 15, 8, 30),
      endTime: new Date(2023, 8, 15, 9, 5),
      distance: 12,
      cost: 650,
      co2Saved: 35
    },
    {
      id: 2,
      origin: "123 Main Street, City Center",
      destination: "789 Tech Campus",
      transportType: "bus",
      startTime: new Date(2023, 8, 14, 8, 15),
      endTime: new Date(2023, 8, 14, 9, 0),
      distance: 14,
      cost: 275,
      co2Saved: 45
    },
    {
      id: 3,
      origin: "123 Main Street, City Center",
      destination: "321 Shopping Center",
      transportType: "ev",
      startTime: new Date(2023, 8, 13, 13, 0),
      endTime: new Date(2023, 8, 13, 13, 25),
      distance: 8,
      cost: 0,
      co2Saved: 100
    },
    {
      id: 4,
      origin: "123 Main Street, City Center",
      destination: "555 Park Avenue",
      transportType: "bike",
      startTime: new Date(2023, 8, 12, 17, 30),
      endTime: new Date(2023, 8, 12, 17, 50),
      distance: 3,
      cost: 0,
      co2Saved: 100
    }
  ];
  
  // Use actual data or fallback
  const displayTripHistory = tripHistory || fallbackTripHistory;
  
  // Apply filters
  const filteredTrips = displayTripHistory.filter(trip => {
    if (filterType !== "all" && trip.transportType !== filterType) {
      return false;
    }
    if (date && format(new Date(trip.startTime), 'yyyy-MM-dd') !== format(date, 'yyyy-MM-dd')) {
      return false;
    }
    return true;
  });
  
  const getTotalStats = () => {
    return {
      totalTrips: filteredTrips.length,
      totalDistance: filteredTrips.reduce((sum, trip) => sum + trip.distance, 0),
      totalCo2Saved: filteredTrips.reduce((sum, trip) => sum + trip.co2Saved, 0),
      totalCost: filteredTrips.reduce((sum, trip) => sum + trip.cost, 0)
    };
  };
  
  const stats = getTotalStats();
  
  const getTransportIcon = (type: string) => {
    switch (type) {
      case 'carpool':
        return <Car className="h-5 w-5 text-primary" />;
      case 'bus':
        return <Bus className="h-5 w-5 text-blue-500" />;
      case 'walk':
        return <svg className="h-5 w-5 text-neutral-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7a4 4 0 11-8 0 4 4 0 018 0zM9 14a6 6 0 00-6 6v1h12v-1a6 6 0 00-6-6zM21 12h-6" />
        </svg>;
      case 'bike':
        return <Bike className="h-5 w-5 text-green-600" />;
      case 'ev':
        return <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>;
      default:
        return <Car className="h-5 w-5 text-neutral-500" />;
    }
  };
  
  const formatCost = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}`;
  };
  
  const formatDate = (date: Date) => {
    return format(new Date(date), 'MMM d, yyyy');
  };
  
  const formatTime = (date: Date) => {
    return format(new Date(date), 'h:mm a');
  };
  
  return (
    <div className="app-container flex flex-col min-h-screen bg-neutral-50">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-6 mb-16 md:mb-0 md:ml-64">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">Trip History</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <BarChart4 className="h-8 w-8 text-primary bg-primary-100 p-1.5 rounded-full mr-3" />
                  <div>
                    <p className="text-sm text-neutral-500">Total Trips</p>
                    <p className="text-2xl font-bold">{stats.totalTrips}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <MapPin className="h-8 w-8 text-blue-500 bg-blue-100 p-1.5 rounded-full mr-3" />
                  <div>
                    <p className="text-sm text-neutral-500">Total Distance</p>
                    <p className="text-2xl font-bold">{stats.totalDistance} mi</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <Leaf className="h-8 w-8 text-green-600 bg-green-100 p-1.5 rounded-full mr-3" />
                  <div>
                    <p className="text-sm text-neutral-500">CO₂ Saved</p>
                    <p className="text-2xl font-bold">{stats.totalCo2Saved} kg</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <DollarSign className="h-8 w-8 text-amber-500 bg-amber-100 p-1.5 rounded-full mr-3" />
                  <div>
                    <p className="text-sm text-neutral-500">Total Spent</p>
                    <p className="text-2xl font-bold">{formatCost(stats.totalCost)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Filter Trips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <p className="text-sm text-neutral-500 mb-2">Transport Type</p>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger>
                      <SelectValue placeholder="All types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All types</SelectItem>
                      <SelectItem value="carpool">Carpool</SelectItem>
                      <SelectItem value="bus">Bus</SelectItem>
                      <SelectItem value="walk">Walk</SelectItem>
                      <SelectItem value="bike">Bike</SelectItem>
                      <SelectItem value="ev">Electric Vehicle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1">
                  <p className="text-sm text-neutral-500 mb-2">Date</p>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, 'PPP') : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={setDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="flex items-end">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setFilterType("all");
                      setDate(undefined);
                    }}
                    className="mb-0.5"
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Tabs defaultValue="list" className="mb-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="list">List View</TabsTrigger>
              <TabsTrigger value="calendar">Calendar View</TabsTrigger>
            </TabsList>
            
            <TabsContent value="list">
              {isLoading ? (
                <div className="space-y-4">
                  <div className="h-24 bg-neutral-100 animate-pulse rounded-lg"></div>
                  <div className="h-24 bg-neutral-100 animate-pulse rounded-lg"></div>
                  <div className="h-24 bg-neutral-100 animate-pulse rounded-lg"></div>
                </div>
              ) : filteredTrips.length > 0 ? (
                <div className="space-y-4">
                  {filteredTrips.map((trip) => (
                    <Card key={trip.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start">
                          <div className={`rounded-full p-2 mr-4 ${
                            trip.transportType === 'carpool' ? 'bg-primary-100' :
                            trip.transportType === 'bus' ? 'bg-blue-100' :
                            trip.transportType === 'ev' ? 'bg-green-100' :
                            trip.transportType === 'bike' ? 'bg-green-100' :
                            'bg-neutral-100'
                          }`}>
                            {getTransportIcon(trip.transportType)}
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex justify-between mb-1">
                              <div>
                                <h3 className="font-medium">
                                  {trip.destination.split(',')[0]}
                                </h3>
                                <p className="text-sm text-neutral-500">
                                  {formatDate(trip.startTime)}
                                </p>
                              </div>
                              
                              <div className="text-right">
                                <Badge className={`${
                                  trip.transportType === 'carpool' ? 'bg-primary text-white' :
                                  trip.transportType === 'bus' ? 'bg-blue-500 text-white' :
                                  'bg-green-500 text-white'
                                }`}>
                                  {trip.transportType.charAt(0).toUpperCase() + trip.transportType.slice(1)}
                                </Badge>
                                <p className="text-sm font-medium mt-1">
                                  {trip.cost > 0 ? formatCost(trip.cost) : 'Free'}
                                </p>
                              </div>
                            </div>
                            
                            <Separator className="my-2" />
                            
                            <div className="grid grid-cols-3 gap-2 text-sm">
                              <div>
                                <p className="text-neutral-500">Time</p>
                                <p>{formatTime(trip.startTime)} - {formatTime(trip.endTime)}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Distance</p>
                                <p>{trip.distance} miles</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">CO₂ Saved</p>
                                <p className="text-green-600">{trip.co2Saved}kg</p>
                              </div>
                            </div>
                            
                            <div className="mt-3 flex space-x-2">
                              <Button size="sm" variant="outline">View Details</Button>
                              <Button size="sm" variant="outline">Repeat Trip</Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-6 text-center">
                    <p className="text-neutral-500">No trips found matching your filters.</p>
                    <Button className="mt-4" onClick={() => {
                      setFilterType("all");
                      setDate(undefined);
                    }}>
                      Clear Filters
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="calendar">
              <Card>
                <CardContent className="p-6">
                  <p className="text-center text-neutral-500">
                    Calendar view is not available in this version.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <MobileNavBar />
      <DesktopSidebar />
    </div>
  );
};

export default History;
