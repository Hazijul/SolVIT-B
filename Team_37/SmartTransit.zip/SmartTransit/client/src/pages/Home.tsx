import { useState } from 'react';
import Header from '@/components/Header';
import Map from '@/components/Map';
import BottomSheet from '@/components/BottomSheet';
import QuickActions from '@/components/QuickActions';
import UserLocationCard from '@/components/UserLocationCard';
import MobileNavBar from '@/components/MobileNavBar';
import DesktopSidebar from '@/components/DesktopSidebar';

const Home = () => {
  const [expandBottomSheet, setExpandBottomSheet] = useState(false);
  const [activeTab, setActiveTab] = useState<'rides' | 'parking' | 'routes'>('routes');
  const [userLocation] = useState('123 Main Street, City Center');

  const handleActionClick = (actionId: string) => {
    setExpandBottomSheet(true);
    // Switch tabs based on the action
    if (actionId === 'carpool') {
      setActiveTab('rides');
    } else if (actionId === 'parking') {
      setActiveTab('parking');
    } else if (actionId === 'routes') {
      setActiveTab('routes');
    }
  };

  const handleDestinationFocus = () => {
    setExpandBottomSheet(true);
  };
  
  const handleMarkerClick = (markerId: string, position: [number, number]) => {
    // Expand bottom sheet when marker is clicked
    setExpandBottomSheet(true);
    
    // Switch to appropriate tab based on marker type
    if (markerId.includes('parking')) {
      setActiveTab('parking');
    } else if (markerId.includes('carpool')) {
      setActiveTab('rides');
    } else if (markerId.includes('transit')) {
      setActiveTab('routes');
    }
    
    // In a real app, we would also fetch data about the specific marker
    console.log(`Marker clicked: ${markerId} at position ${position}`);
  };

  return (
    <div className="app-container flex flex-col h-screen">
      <Header />
      
      <main className="flex-1 relative overflow-hidden">
        <Map onMarkerClick={handleMarkerClick} />
        
        <UserLocationCard 
          userLocation={userLocation} 
          onDestinationFocus={handleDestinationFocus} 
        />
        
        <QuickActions onActionClick={handleActionClick} />
        
        <BottomSheet 
          expanded={expandBottomSheet} 
          defaultState={expandBottomSheet ? "expanded" : "partial"}
          activeTab={activeTab}
        />
      </main>
      
      <MobileNavBar />
      <DesktopSidebar />
    </div>
  );
};

export default Home;
