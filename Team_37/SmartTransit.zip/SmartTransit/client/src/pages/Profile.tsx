import { useState } from 'react';
import Header from '@/components/Header';
import MobileNavBar from '@/components/MobileNavBar';
import DesktopSidebar from '@/components/DesktopSidebar';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, Leaf, User, DollarSign, Car } from 'lucide-react';

const Profile = () => {
  const [travelPreference, setTravelPreference] = useState('fastest');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  return (
    <div className="app-container flex flex-col min-h-screen bg-neutral-50">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6 mb-16 md:mb-0 md:ml-64">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center mb-6">
            <Avatar className="h-20 w-20 mr-4">
              <AvatarImage src="https://randomuser.me/api/portraits/men/32.jpg" alt="User profile" />
              <AvatarFallback>PN</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold">Pranav</h1>
              <p className="text-neutral-500">pranav@navisense.com</p>
              <div className="flex mt-2">
                <Button size="sm" className="mr-2">Edit Profile</Button>
                <Button size="sm" variant="outline">Change Password</Button>
              </div>
            </div>
          </div>

          <Tabs defaultValue="preferences">
            <TabsList className="w-full mb-6">
              <TabsTrigger value="preferences" className="flex-1">Preferences</TabsTrigger>
              <TabsTrigger value="vehicles" className="flex-1">Vehicles</TabsTrigger>
              <TabsTrigger value="payment" className="flex-1">Payment</TabsTrigger>
              <TabsTrigger value="account" className="flex-1">Account</TabsTrigger>
            </TabsList>

            <TabsContent value="preferences">
              <Card>
                <CardHeader>
                  <CardTitle>Travel Preferences</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label className="text-base">Default Travel Mode</Label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                      <Button 
                        variant={travelPreference === 'fastest' ? 'default' : 'outline'}
                        onClick={() => setTravelPreference('fastest')}
                        className="justify-start"
                      >
                        <Clock className="h-4 w-4 mr-2" /> Fastest
                      </Button>
                      <Button 
                        variant={travelPreference === 'cheapest' ? 'default' : 'outline'}
                        onClick={() => setTravelPreference('cheapest')}
                        className="justify-start"
                      >
                        <DollarSign className="h-4 w-4 mr-2" /> Cheapest
                      </Button>
                      <Button 
                        variant={travelPreference === 'eco' ? 'default' : 'outline'}
                        onClick={() => setTravelPreference('eco')}
                        className="justify-start"
                      >
                        <Leaf className="h-4 w-4 mr-2" /> Eco-Friendly
                      </Button>
                      <Button 
                        variant={travelPreference === 'social' ? 'default' : 'outline'}
                        onClick={() => setTravelPreference('social')}
                        className="justify-start"
                      >
                        <User className="h-4 w-4 mr-2" /> Social
                      </Button>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="time-flexibility">Time Flexibility (minutes)</Label>
                      <Select defaultValue="15">
                        <SelectTrigger id="time-flexibility">
                          <SelectValue placeholder="Select flexibility" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">Exact time</SelectItem>
                          <SelectItem value="5">±5 minutes</SelectItem>
                          <SelectItem value="15">±15 minutes</SelectItem>
                          <SelectItem value="30">±30 minutes</SelectItem>
                          <SelectItem value="60">±1 hour</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="vehicle-type">Default Vehicle Type</Label>
                      <Select defaultValue="hybrid">
                        <SelectTrigger id="vehicle-type">
                          <SelectValue placeholder="Select vehicle type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="gas">Gas Car</SelectItem>
                          <SelectItem value="hybrid">Hybrid</SelectItem>
                          <SelectItem value="electric">Electric Vehicle</SelectItem>
                          <SelectItem value="none">No Vehicle</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="max-parking-price">Max Parking Price ($/hr)</Label>
                      <Input id="max-parking-price" type="number" placeholder="10" defaultValue="10" />
                    </div>

                    <div>
                      <Label htmlFor="home-address">Home Address</Label>
                      <Input id="home-address" placeholder="Enter your home address" defaultValue="456 Residential Ave" />
                    </div>

                    <div>
                      <Label htmlFor="work-address">Work Address</Label>
                      <Input id="work-address" placeholder="Enter your work address" defaultValue="123 Business St" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="notifications" className="text-base">Push Notifications</Label>
                      <div className="text-sm text-neutral-500">Receive ride and parking alerts</div>
                    </div>
                    <Switch
                      id="notifications"
                      checked={notificationsEnabled}
                      onCheckedChange={setNotificationsEnabled}
                    />
                  </div>

                  <Button className="w-full sm:w-auto">Save Preferences</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="vehicles">
              <Card>
                <CardHeader>
                  <CardTitle>My Vehicles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4 flex items-start">
                      <div className="bg-primary-100 p-3 rounded-full mr-4">
                        <Car className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <h3 className="font-medium">Toyota Prius</h3>
                          <span className="text-green-600 text-sm font-medium">Hybrid</span>
                        </div>
                        <p className="text-sm text-neutral-500">License: ABC123</p>
                        <div className="flex mt-2">
                          <Button size="sm" variant="outline" className="mr-2">Edit</Button>
                          <Button size="sm" variant="outline" className="text-red-500 hover:text-red-600">Remove</Button>
                        </div>
                      </div>
                    </div>

                    <Button className="w-full">Add Vehicle</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payment">
              <Card>
                <CardHeader>
                  <CardTitle>Payment Methods</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4 flex items-start">
                      <div className="bg-neutral-100 p-2 rounded-full mr-4">
                        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <rect x="2" y="4" width="20" height="16" rx="2" stroke="currentColor" strokeWidth="2" />
                          <path d="M2 10H22" stroke="currentColor" strokeWidth="2" />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <h3 className="font-medium">Visa ending in 1234</h3>
                          <span className="text-neutral-500 text-sm">Default</span>
                        </div>
                        <p className="text-sm text-neutral-500">Expires 12/24</p>
                        <div className="flex mt-2">
                          <Button size="sm" variant="outline" className="mr-2">Edit</Button>
                          <Button size="sm" variant="outline" className="text-red-500 hover:text-red-600">Remove</Button>
                        </div>
                      </div>
                    </div>

                    <Button className="w-full">Add Payment Method</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="account">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input id="email" type="email" defaultValue="pranav@navisense.com" />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" type="tel" defaultValue="(555) 123-4567" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="first-name">First Name</Label>
                        <Input id="first-name" defaultValue="Pranav" />
                      </div>
                      <div>
                        <Label htmlFor="last-name">Last Name</Label>
                        <Input id="last-name" defaultValue="" />
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <Button variant="destructive">Delete Account</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <MobileNavBar />
      <DesktopSidebar />
    </div>
  );
};

export default Profile;