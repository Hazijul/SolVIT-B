import { useState } from 'react';
import Header from '@/components/Header';
import MobileNavBar from '@/components/MobileNavBar';
import DesktopSidebar from '@/components/DesktopSidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, MapPin } from 'lucide-react';
import Map from '@/components/Map';

const Explore = () => {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="app-container flex flex-col h-screen">
      <Header />
      
      <main className="flex-1 relative overflow-hidden">
        <Map />
        
        <div className="absolute top-4 left-4 right-4 z-10">
          <div className="bg-white rounded-lg shadow-lg p-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-4 w-4 text-neutral-400" />
              </div>
              <Input 
                type="text" 
                className="w-full pl-10 pr-20 py-2" 
                placeholder="Search locations" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                className="absolute right-1 top-1/2 transform -translate-y-1/2"
                size="sm"
              >
                Search
              </Button>
            </div>
          </div>
        </div>
        
        {searchQuery && (
          <div className="absolute top-24 left-4 right-4 z-10 bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="p-2 text-sm text-neutral-500">Search results for "{searchQuery}"</div>
            <div className="border-t">
              <div className="p-3 hover:bg-neutral-50 flex items-start cursor-pointer">
                <MapPin className="h-5 w-5 text-neutral-400 mr-2 mt-0.5" />
                <div>
                  <div className="font-medium">Downtown Shopping Center</div>
                  <div className="text-sm text-neutral-500">789 Shopping Avenue, City Center</div>
                </div>
              </div>
              <div className="p-3 hover:bg-neutral-50 flex items-start cursor-pointer border-t">
                <MapPin className="h-5 w-5 text-neutral-400 mr-2 mt-0.5" />
                <div>
                  <div className="font-medium">Central Park</div>
                  <div className="text-sm text-neutral-500">123 Park Street, City Center</div>
                </div>
              </div>
              <div className="p-3 hover:bg-neutral-50 flex items-start cursor-pointer border-t">
                <MapPin className="h-5 w-5 text-neutral-400 mr-2 mt-0.5" />
                <div>
                  <div className="font-medium">Tech Hub Campus</div>
                  <div className="text-sm text-neutral-500">456 Innovation Blvd, Tech District</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
      
      <MobileNavBar />
      <DesktopSidebar />
    </div>
  );
};

export default Explore;
