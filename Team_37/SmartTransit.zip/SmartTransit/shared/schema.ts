import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  preferences: json("preferences").$type<UserPreferences>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Ride model
export const rides = pgTable("rides", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").references(() => users.id),
  origin: text("origin").notNull(),
  destination: text("destination").notNull(),
  departureTime: timestamp("departure_time").notNull(),
  arrivalTime: timestamp("arrival_time").notNull(),
  availableSeats: integer("available_seats").notNull(),
  cost: integer("cost").notNull(),
  description: text("description"),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Ride reservation model
export const rideReservations = pgTable("ride_reservations", {
  id: serial("id").primaryKey(),
  rideId: integer("ride_id").references(() => rides.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Parking model
export const parkingSpots = pgTable("parking_spots", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  lat: text("lat").notNull(),
  lng: text("lng").notNull(),
  hourlyRate: integer("hourly_rate").notNull(),
  totalSpots: integer("total_spots").notNull(),
  availableSpots: integer("available_spots").notNull(),
  restrictions: text("restrictions"),
  features: json("features").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Trip history model
export const tripHistory = pgTable("trip_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  origin: text("origin").notNull(),
  destination: text("destination").notNull(),
  transportType: text("transport_type").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  distance: integer("distance").notNull(),
  cost: integer("cost"),
  co2Saved: integer("co2_saved"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Types
export type UserPreferences = {
  travelMode: 'fastest' | 'cheapest' | 'eco' | 'social';
  timeFlexibility: number;
  vehicleType?: 'gas' | 'hybrid' | 'electric' | 'none';
  maxParkingPrice?: number;
  parkingReservable?: boolean;
  routePreference?: 'eco' | 'fastest' | 'fuelEfficient' | 'multiModal';
  notificationEnabled?: boolean;
};

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertRideSchema = createInsertSchema(rides).omit({
  id: true,
  createdAt: true,
});

export const insertRideReservationSchema = createInsertSchema(rideReservations).omit({
  id: true,
  createdAt: true,
});

export const insertParkingSpotSchema = createInsertSchema(parkingSpots).omit({
  id: true,
  createdAt: true,
});

export const insertTripHistorySchema = createInsertSchema(tripHistory).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertRide = z.infer<typeof insertRideSchema>;
export type InsertRideReservation = z.infer<typeof insertRideReservationSchema>;
export type InsertParkingSpot = z.infer<typeof insertParkingSpotSchema>;
export type InsertTripHistory = z.infer<typeof insertTripHistorySchema>;

export type User = typeof users.$inferSelect;
export type Ride = typeof rides.$inferSelect;
export type RideReservation = typeof rideReservations.$inferSelect;
export type ParkingSpot = typeof parkingSpots.$inferSelect;
export type TripHistory = typeof tripHistory.$inferSelect;
